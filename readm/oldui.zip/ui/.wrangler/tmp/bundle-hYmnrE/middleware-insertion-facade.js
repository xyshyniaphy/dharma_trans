				import { __facade_registerInternal__ } from "/home/xyshyniaphy/dharma_trans/ui/node_modules/wrangler/templates/middleware/loader-sw.ts";
				import * as __MIDDLEWARE_0__ from "/home/xyshyniaphy/dharma_trans/ui/node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts";
import * as __MIDDLEWARE_1__ from "/home/xyshyniaphy/dharma_trans/ui/node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts";
				__facade_registerInternal__([__MIDDLEWARE_0__.default,__MIDDLEWARE_1__.default])